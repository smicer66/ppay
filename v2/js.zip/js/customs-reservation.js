
jQuery(function($) {

	"use strict";
		
	/**
	 * WYSIHTML5 -  A better approach to rich text editing
	 */
	$('.bootstrap3-wysihtml5').wysihtml5({});
	
});

